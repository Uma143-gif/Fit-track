# FitTrack Android

Personal calorie, food, water, workout and weight diary.

## Build APK
1. Upload all files and folders in this project to the root of your GitHub repository.
2. Open the **Actions** tab.
3. Select **Build FitTrack APK** and tap **Run workflow** (or wait for the push-triggered build).
4. Open the completed workflow run and download the `FitTrack-debug-APK` artifact.
5. Extract the artifact ZIP on Android and install `app-debug.apk`.

The app stores diary entries locally on the device. Export a JSON backup from Reports before clearing app data or uninstalling.
